import React from "react";
import NewsItem from "./NewsItem";
import "./News.css";

const News = () => {
  return (
    <div>
      <iframe
        width="560"
        height="315"
        src="https://www.youtube.com/embed/cLYg_M5jo00"
        frameborder="0"
        allowfullscreen
      ></iframe>
      <div>
        <img
          src="/wc_image/result.png"
          alt="wordcloud_img"
          style={{ width: "300px", height: "300px" }}
        />
      </div>
      <NewsItem />
    </div>
  );
};

export default News;
